<?php

$Name=$_POST['name'];
$Phone_Number=$_POST['phoneNumber'];
$E_mail=$_POST['e-mail'];
$Message=$_POST['query'];

//Database Connection
$conn=new mysql('localhost','root','','contactform');
if($conn->connect_error){
    die('Connection Failed:'.$conn->connect_error);
}else{
    $stmt=$conn->prepare("insert into tab1(name,phoneNumber,e-mail,query)values(?,?,?,?)");
    $stmt->bind_param("siss,$name,$phoneNumber,$e-mail,$query");
    $stmt->execute();
    echo "goodjob";
    $stmt->close();
    $conn->close();
?>